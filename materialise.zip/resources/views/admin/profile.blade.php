@extends('layouts/layoutMaster')

@section('title', 'Admin Profile')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">
    <!-- Profile Photo -->
    <div class="col-md-6 col-12 mb-4">
      <div class="card">
        <div class="card-header">
          <h5 class="mb-0">Profile Photo</h5>
        </div>
        <div class="card-body">
          @if (session('success'))
            <div class="alert alert-success mb-4">
              {{ session('success') }}
            </div>
          @endif

          <div class="d-flex align-items-start align-items-sm-center gap-4 mb-4">
            <img src="{{ $user->profile_photo_url }}" alt="user-avatar" class="d-block rounded" height="100" width="100" id="uploadedAvatar" />
            <div class="button-wrapper">
              <form action="{{ route('admin.profile.photo') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <label for="upload" class="btn btn-primary me-2 mb-3" tabindex="0">
                  <span class="d-none d-sm-block">Upload new photo</span>
                  <i class="icon-base ri ri-upload-2-line d-block d-sm-none"></i>
                  <input type="file" id="upload" name="photo" class="account-file-input" hidden accept="image/png, image/jpeg, image/jpg" onchange="this.form.submit()" />
                </label>
              </form>
              <p class="text-body-secondary mb-0">Allowed JPG or PNG. Max size of 2MB</p>
            </div>
          </div>

          @error('photo')
            <div class="alert alert-danger">{{ $message }}</div>
          @enderror
        </div>
      </div>
    </div>

    <!-- Change Password -->
    <div class="col-md-6 col-12 mb-4">
      <div class="card">
        <div class="card-header">
          <h5 class="mb-0">Change Password</h5>
        </div>
        <div class="card-body">
          <form action="{{ route('admin.profile.password') }}" method="POST">
            @csrf
            <div class="mb-3">
              <label for="current_password" class="form-label">Current Password</label>
              <div class="input-group input-group-merge">
                <input type="password" class="form-control @error('current_password') is-invalid @enderror" id="current_password" name="current_password" placeholder="Enter current password" />
                <span class="input-group-text cursor-pointer"><i class="icon-base ri ri-eye-off-line"></i></span>
              </div>
              @error('current_password')
                <div class="invalid-feedback d-block">{{ $message }}</div>
              @enderror
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">New Password</label>
              <div class="input-group input-group-merge">
                <input type="password" class="form-control @error('password') is-invalid @enderror" id="password" name="password" placeholder="Enter new password" />
                <span class="input-group-text cursor-pointer"><i class="icon-base ri ri-eye-off-line"></i></span>
              </div>
              @error('password')
                <div class="invalid-feedback d-block">{{ $message }}</div>
              @enderror
            </div>
            <div class="mb-3">
              <label for="password_confirmation" class="form-label">Confirm New Password</label>
              <div class="input-group input-group-merge">
                <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Confirm new password" />
              </div>
            </div>
            <button type="submit" class="btn btn-primary">Update Password</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
