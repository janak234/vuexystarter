@php
  use Illuminate\Support\Facades\Auth;
@endphp

@extends('layouts/layoutMaster')

@section('title', 'Admin Dashboard')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h5 class="mb-0">Welcome to Admin Dashboard</h5>
        </div>
        <div class="card-body">
          <p>Hello, {{ Auth::user()->name }}! You are logged in as an administrator.</p>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
