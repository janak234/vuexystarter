<?php $__env->startSection('title', 'Admin Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">
    <!-- Profile Photo -->
    <div class="col-md-6 col-12 mb-4">
      <div class="card">
        <div class="card-header">
          <h5 class="mb-0">Profile Photo</h5>
        </div>
        <div class="card-body">
          <?php if(session('success')): ?>
            <div class="alert alert-success mb-4">
              <?php echo e(session('success')); ?>

            </div>
          <?php endif; ?>

          <div class="d-flex align-items-start align-items-sm-center gap-4 mb-4">
            <img src="<?php echo e($user->profile_photo_url); ?>" alt="user-avatar" class="d-block rounded" height="100" width="100" id="uploadedAvatar" />
            <div class="button-wrapper">
              <form action="<?php echo e(route('admin.profile.photo')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label for="upload" class="btn btn-primary me-2 mb-3" tabindex="0">
                  <span class="d-none d-sm-block">Upload new photo</span>
                  <i class="icon-base ri ri-upload-2-line d-block d-sm-none"></i>
                  <input type="file" id="upload" name="photo" class="account-file-input" hidden accept="image/png, image/jpeg, image/jpg" onchange="this.form.submit()" />
                </label>
              </form>
              <p class="text-body-secondary mb-0">Allowed JPG or PNG. Max size of 2MB</p>
            </div>
          </div>

          <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
    </div>

    <!-- Change Password -->
    <div class="col-md-6 col-12 mb-4">
      <div class="card">
        <div class="card-header">
          <h5 class="mb-0">Change Password</h5>
        </div>
        <div class="card-body">
          <form action="<?php echo e(route('admin.profile.password')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="current_password" class="form-label">Current Password</label>
              <div class="input-group input-group-merge">
                <input type="password" class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="current_password" name="current_password" placeholder="Enter current password" />
                <span class="input-group-text cursor-pointer"><i class="icon-base ri ri-eye-off-line"></i></span>
              </div>
              <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">New Password</label>
              <div class="input-group input-group-merge">
                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" placeholder="Enter new password" />
                <span class="input-group-text cursor-pointer"><i class="icon-base ri ri-eye-off-line"></i></span>
              </div>
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
              <label for="password_confirmation" class="form-label">Confirm New Password</label>
              <div class="input-group input-group-merge">
                <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Confirm new password" />
              </div>
            </div>
            <button type="submit" class="btn btn-primary">Update Password</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/janakpatel/Desktop/rentalapp/rentalapp/resources/views/admin/profile.blade.php ENDPATH**/ ?>