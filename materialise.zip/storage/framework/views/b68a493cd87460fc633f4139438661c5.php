<?php
  use Illuminate\Support\Facades\Auth;
?>



<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h5 class="mb-0">Welcome to Admin Dashboard</h5>
        </div>
        <div class="card-body">
          <p>Hello, <?php echo e(Auth::user()->name); ?>! You are logged in as an administrator.</p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/janakpatel/Desktop/rentalapp/rentalapp/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>