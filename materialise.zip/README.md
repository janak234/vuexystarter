```bash
ssh root@72.61.207.189
q9eaAsvVYIhUnnOUK2C#

==================================================================
aaPanel Internet Address: https://72.61.207.189:28064/e052bf86
aaPanel Internal Address: https://72.61.207.189:28064/e052bf86
username: durgfko4
password: ce1a9527
Warning:
If you cannot access the panel, 
release the following port (28064|888|80|443|20|21) in the security group
==================================================================

hostinger: 
shingimarigah@gmail.com
N#mpilo365%
```