<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\language\LanguageController;
use App\Http\Controllers\pages\HomePage;
use App\Http\Controllers\pages\Page2;
use App\Http\Controllers\pages\MiscError;
use App\Http\Controllers\authentications\LoginBasic;
use App\Http\Controllers\authentications\RegisterBasic;
use App\Http\Controllers\Admin\AdminController;

// Main Page Route - redirect to admin login if not authenticated
Route::get('/', function () {
    if (!Auth::check()) {
        return redirect()->route('admin.login');
    }
    return app(HomePage::class)->index();
})->name('pages-home');
Route::get('/page-2', [Page2::class, 'index'])->name('pages-page-2')->middleware('admin');

// locale
Route::get('/lang/{locale}', [LanguageController::class, 'swap']);
Route::get('/pages/misc-error', [MiscError::class, 'index'])->name('pages-misc-error');

// authentication
Route::get('/auth/login-basic', [LoginBasic::class, 'index'])->name('auth-login-basic');
Route::get('/auth/register-basic', [RegisterBasic::class, 'index'])->name('auth-register-basic');

// Admin Routes
Route::prefix('admin')->group(function () {
    Route::get('/login', [AdminController::class, 'showLoginForm'])->name('admin.login');
    Route::post('/login', [AdminController::class, 'login'])->name('admin.login.submit');

    Route::middleware('admin')->group(function () {
        Route::get('/', [AdminController::class, 'dashboard'])->name('admin.dashboard');
        Route::get('/profile', [AdminController::class, 'profile'])->name('admin.profile');
        Route::post('/profile/photo', [AdminController::class, 'updatePhoto'])->name('admin.profile.photo');
        Route::post('/profile/password', [AdminController::class, 'updatePassword'])->name('admin.profile.password');
        Route::post('/logout', [AdminController::class, 'logout'])->name('admin.logout');
    });
});
