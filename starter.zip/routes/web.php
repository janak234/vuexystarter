<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\language\LanguageController;
use App\Http\Controllers\pages\HomePage;
use App\Http\Controllers\pages\Page2;
use App\Http\Controllers\pages\MiscError;
use App\Http\Controllers\authentications\LoginBasic;
use App\Http\Controllers\authentications\RegisterBasic;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Middleware\AdminMiddleware;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\UsersController;
use App\Http\Controllers\User\DashboardController as UserDashboardController;
use App\Http\Controllers\User\PromptsController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Admin\ProfileController;

// Home route with role-based redirection
Route::get('/', function () {
    if (Auth::check()) {
        return Auth::user()->isAdmin() 
            ? redirect()->route('admin-dashboard')
            : redirect()->route('user-dashboard');
    }
    return redirect()->route('login');
});

Route::middleware(['web'])->group(function () {
    // Laravel's default authentication routes
    Route::get('login', [LoginBasic::class, 'index'])->name('login');
    Route::post('login', [LoginBasic::class, 'login']);
    Route::post('logout', [LoginBasic::class, 'logout'])->name('logout');

    // Register routes
    Route::get('register', [RegisterBasic::class, 'index'])->name('register');
    Route::post('register', [RegisterBasic::class, 'register']);

    // Admin routes
    Route::group([
        'prefix' => 'admin',
        'middleware' => ['auth', AdminMiddleware::class]
    ], function () {
        Route::get('/', [AdminDashboardController::class, 'index'])->name('admin-dashboard');
        Route::get('/users', [UsersController::class, 'index'])->name('admin-users');
        Route::get('/profile', [\App\Http\Controllers\Admin\ProfileController::class, 'index'])->name('admin-profile');
        Route::post('/profile', [\App\Http\Controllers\Admin\ProfileController::class, 'update'])->name('admin-profile.update');
        Route::post('/profile/password', [\App\Http\Controllers\Admin\ProfileController::class, 'updatePassword'])->name('admin-profile.password');
    });

    // User routes
    Route::group([
        'prefix' => 'user',
        'middleware' => ['auth']
    ], function () {
        Route::get('/', [UserDashboardController::class, 'index'])->name('user-dashboard');
        Route::get('/prompts', [PromptsController::class, 'index'])->name('user-prompts');
        Route::get('/profile', [\App\Http\Controllers\User\ProfileController::class, 'index'])->name('user-profile');
        Route::post('/profile', [\App\Http\Controllers\User\ProfileController::class, 'update'])->name('user-profile.update');
        Route::post('/profile/password', [\App\Http\Controllers\User\ProfileController::class, 'updatePassword'])->name('user-profile.password');
    });

    // locale
    Route::get('/lang/{locale}', [LanguageController::class, 'swap']);
    Route::get('/pages/misc-error', [MiscError::class, 'index'])->name('pages-misc-error');
});
