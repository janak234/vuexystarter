<?php
$containerFooter = (isset($configData['contentLayout']) && $configData['contentLayout'] === 'compact') ? 'container-xxl' : 'container-fluid';
?>

<!-- Footer-->
<footer class="content-footer footer bg-footer-theme">
  <div class="<?php echo e($containerFooter); ?>">
    <div class="footer-container d-flex align-items-center justify-content-between py-4 flex-md-row flex-column">
      <div class="text-body">
        Copyright © <script>document.write(new Date().getFullYear())</script>
      </div>
      
    </div>
  </div>
</footer>
<!--/ Footer-->
<?php /**PATH D:\projs\prompt-app\resources\views/layouts/sections/footer/footer.blade.php ENDPATH**/ ?>