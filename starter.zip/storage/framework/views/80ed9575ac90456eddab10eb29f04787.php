<?php
$configData = Helper::appClasses();
?>



<?php $__env->startSection('title', 'Page 2'); ?>

<?php $__env->startSection('content'); ?>
<h4>Page 2</h4>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projs\prompt-app\resources\views/content/pages/pages-page2.blade.php ENDPATH**/ ?>